﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForm
{
    /// <summary>
    /// 常量
    /// </summary>
    public class ConstVar
    {
        /// <summary>
        /// 区域网址
        /// </summary>
        public const string AreaUrl = "http://www.58.com/changecity.html?fullpath=&PGTID=0d100000-0094-a518-c06b-0edf94a2cb42&ClickID=1";
    }
}
