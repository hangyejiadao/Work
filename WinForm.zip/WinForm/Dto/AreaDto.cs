﻿
namespace Dto
{
   
    public class AreaDto
    {

    }
}
